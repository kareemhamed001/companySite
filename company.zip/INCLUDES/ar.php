<?php
$main="الرئيسيه";
$us="من نحن";
$latest="اخر الاخبار";
$ourProjects="مشاريعنا";
$services="خدماتنا";
$contactUs="تواصل معنا";
?>