<!-- The Modal -->
<div class="modal fade" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">تأكيد الحذف؟</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                <form action="" method="get" class="d-flex justify-content-center ">
                            <input id="cover-name" type="hidden" name="name" value="'.$value['imageName'].'">
                            <input id="cover-id" type="hidden" name="id" value="'.$value['id'].'">
                            <button type="submit" name="delete" class="btn btn-danger" style="width: 6em; margin-right:0.5em">نعم</button>
                            <button type="submit"  class="btn btn-danger" data-bs-dismiss="modal" style="width: 6em;margin-left:0.5em">لا</button>
                        </form>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>