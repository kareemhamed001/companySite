<nav class="container p-3 navbar-dark fixed-top bg-dark  ">
    <ul class="nav  justify-content-center">
      <li class="nav-item  ">
        <a class="nav-link text-white " href="../Admin/cover.php">الغلاق</a>
      </li>
      <li class="nav-item  ">
        <a class="nav-link text-white" href="../Admin/services.php">خدماتنا </a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-white" href="../Admin/projects.php">مشاريعنا</a>
      </li>
    
    </ul>
  
</nav>

<!-- <nav class="navbar navbar-expand-sm bg-light navbar-light d-flex justify-content-center">
    <div class="container-fluid w-100 ">
        <ul class="navbar-nav w-100 ">
            <li class="nav-item">
                <a class="nav-link" href=""><?php echo $contactUs; ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href=""><?php echo $latest; ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#aboutUs"><?php echo $us; ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="projects.php"><?php echo $ourProjects; ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="services.php"><?php echo $services; ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="cover.php"><?php echo $main; ?></a>
            </li>
        </ul>
    </div>
</nav> -->
